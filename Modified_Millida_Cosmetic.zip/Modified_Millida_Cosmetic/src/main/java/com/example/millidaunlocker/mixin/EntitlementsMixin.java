package com.example.millidaunlocker.mixin;

import net.millida.core.cosmetics.Entitlements;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = Entitlements.class, remap = false)
public class EntitlementsMixin {

    @Inject(method = "owns", at = @At("HEAD"), cancellable = true, remap = false)
    private void unlockAllItems(String code, CallbackInfoReturnable<Boolean> cir) {
        if (code != null) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "ownsVariant", at = @At("HEAD"), cancellable = true, remap = false)
    private void unlockAllVariants(String code, String variant, CallbackInfoReturnable<Boolean> cir) {
        if (code != null) {
            cir.setReturnValue(true);
        }
    }
}
