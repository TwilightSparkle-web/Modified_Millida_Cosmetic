package com.example.millidaunlocker.mixin;

import com.example.millidaunlocker.UnlockerConfig;
import net.millida.core.MillidaSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = MillidaSettings.class, remap = false)
public class MillidaSettingsMixin {

    @Inject(method = "hasToken", at = @At("HEAD"), cancellable = true, remap = false)
    private void alwaysHasToken(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(true);
    }

    @Inject(method = "token", at = @At("HEAD"), cancellable = true, remap = false)
    private void interceptOrProvideToken(CallbackInfoReturnable<String> cir) {
        // 1. Проверяем, не передал ли лаунчер свежий токен через окружение
        String envToken = System.getProperty("millida.token");
        if (envToken == null || envToken.trim().isEmpty()) {
            envToken = System.getenv("MILLIDA_TOKEN");
        }
        if (envToken != null && !envToken.trim().isEmpty()) {
            UnlockerConfig.saveToken(envToken.trim());
            cir.setReturnValue(envToken.trim());
            return;
        }

        // 2. Иначе берем токен, сохраненный в millida_unlocker.properties
        String savedToken = UnlockerConfig.getToken();
        if (savedToken != null && !savedToken.isEmpty()) {
            cir.setReturnValue(savedToken);
        }
    }
}
