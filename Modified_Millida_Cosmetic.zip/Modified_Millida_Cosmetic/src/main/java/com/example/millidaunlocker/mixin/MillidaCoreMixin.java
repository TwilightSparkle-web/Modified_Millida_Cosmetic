package com.example.millidaunlocker.mixin;

import net.millida.core.MillidaCore;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = MillidaCore.class, remap = false)
public class MillidaCoreMixin {

    @Inject(method = "keyRejected", at = @At("HEAD"), cancellable = true, remap = false)
    private void neverRejected(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
    }

    @Inject(method = "saveEquipped", at = @At("HEAD"), cancellable = true, remap = false)
    private void fakeSaveEquipped(String body, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(true);
    }
}
