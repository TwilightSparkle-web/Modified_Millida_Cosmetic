package com.example.millidaunlocker.mixin;

import net.millida.mod.Millida;
import net.millida.mod.cosmetics.CosmeticRenderLayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = CosmeticRenderLayer.class, remap = false)
public class CosmeticRenderLayerMixin {

    @Unique private static boolean loggedOnce = false;

    @Inject(method = "submit", at = @At("HEAD"), remap = false)
    private void debugRender(CallbackInfo ci) {
        if (!loggedOnce) {
            loggedOnce = true;
            System.out.println("[MillidaUnlocker] CosmeticRenderLayer.submit() CALLED! started=" + Millida.started()
                + ", worn=" + (Millida.wardrobe() != null ? Millida.wardrobe().wornItems().size() : "null"));
        }
    }
}
