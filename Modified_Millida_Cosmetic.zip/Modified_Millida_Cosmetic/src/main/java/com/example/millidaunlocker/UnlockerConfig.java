package com.example.millidaunlocker;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;
import net.millida.core.cosmetics.CosmeticSlot;
import net.millida.core.cosmetics.EquippedCosmetic;

public final class UnlockerConfig {
    private static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir();
    private static final Path FILE = CONFIG_DIR.resolve("millida_unlocker.properties");
    private static final Path WORN_FILE = CONFIG_DIR.resolve("millida_worn.txt");

    private static String customUsername = "";
    private static String customUuid = "";
    private static String launcherToken = "";
    private static boolean loaded = false;

    public static void load() {
        if (loaded) return;
        loaded = true;
        System.out.println("[MillidaUnlocker] Reading config from: " + FILE.toAbsolutePath());
        Properties props = new Properties();
        if (Files.exists(FILE)) {
            try (var in = Files.newInputStream(FILE)) {
                props.load(in);
                customUsername = props.getProperty("username", "").trim();
                customUuid = props.getProperty("uuid", "").trim();
                launcherToken = props.getProperty("token", "").trim();
                System.out.println("[MillidaUnlocker] Token loaded: " + (!launcherToken.isEmpty()) + ", length=" + launcherToken.length());
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            saveConfig("", "", "");
        }
    }

    private static void saveConfig(String username, String uuid, String token) {
        Properties props = new Properties();
        props.setProperty("username", username == null ? "" : username);
        props.setProperty("uuid", uuid == null ? "" : uuid);
        props.setProperty("token", token == null ? "" : token);
        try {
            Files.createDirectories(FILE.getParent());
            try (var out = Files.newOutputStream(FILE)) {
                props.store(out, "Millida Unlocker Config");
            }
        } catch (IOException ignored) {}
    }

    public static String getToken() {
        load();
        return launcherToken.isEmpty() ? null : launcherToken;
    }

    public static void saveToken(String token) {
        load();
        if (token != null && !token.isEmpty() && !token.equals(launcherToken)) {
            launcherToken = token;
            saveConfig(customUsername, customUuid, launcherToken);
        }
    }

    public static UUID resolveUuid(UUID fallback) {
        load();
        if (!customUuid.isEmpty()) {
            try {
                return UUID.fromString(customUuid);
            } catch (IllegalArgumentException ignored) {}
        }
        if (!customUsername.isEmpty()) {
            return UUID.nameUUIDFromBytes(("OfflinePlayer:" + customUsername).getBytes(StandardCharsets.UTF_8));
        }
        if (fallback != null) {
            if (!fallback.toString().equals(customUuid)) {
                customUuid = fallback.toString();
                saveConfig(customUsername, customUuid, launcherToken);
            }
            return fallback;
        }
        return UUID.nameUUIDFromBytes("OfflinePlayer:Player".getBytes(StandardCharsets.UTF_8));
    }

    public static void saveWorn(Iterable<EquippedCosmetic> items) {
        List<String> lines = new ArrayList<>();
        for (EquippedCosmetic item : items) {
            String variant = item.variant() == null ? "" : item.variant();
            String side = item.side() == null ? "" : item.side();
            lines.add(item.itemId() + ";" + item.slot().name() + ";" + item.color() + ";" + variant + ";" + side);
        }
        try {
            Files.createDirectories(WORN_FILE.getParent());
            Files.write(WORN_FILE, lines, StandardCharsets.UTF_8);
        } catch (IOException ignored) {}
    }

    public static List<EquippedCosmetic> loadWorn() {
        List<EquippedCosmetic> list = new ArrayList<>();
        if (!Files.exists(WORN_FILE)) return list;
        try {
            for (String line : Files.readAllLines(WORN_FILE, StandardCharsets.UTF_8)) {
                String[] parts = line.split(";", -1);
                if (parts.length >= 3) {
                    String id = parts[0];
                    CosmeticSlot slot = CosmeticSlot.valueOf(parts[1]);
                    int color = Integer.parseInt(parts[2]);
                    String variant = parts.length > 3 && !parts[3].isEmpty() ? parts[3] : null;
                    String side = parts.length > 4 && !parts[4].isEmpty() ? parts[4] : null;
                    list.add(new EquippedCosmetic(id, slot, color, 0L, variant, side));
                }
            }
        } catch (Exception ignored) {}
        return list;
    }
}
