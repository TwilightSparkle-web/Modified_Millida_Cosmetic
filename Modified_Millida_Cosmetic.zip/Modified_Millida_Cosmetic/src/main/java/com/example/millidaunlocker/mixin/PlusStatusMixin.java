package com.example.millidaunlocker.mixin;

import net.millida.core.cosmetics.PlusStatus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = PlusStatus.class, remap = false)
public class PlusStatusMixin {

    @Inject(method = "active", at = @At("HEAD"), cancellable = true, remap = false)
    private void forcePlusActive(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(true);
    }

    @Inject(method = "known", at = @At("HEAD"), cancellable = true, remap = false)
    private void forcePlusKnown(CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(true);
    }
}
