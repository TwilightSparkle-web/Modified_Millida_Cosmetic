package com.example.millidaunlocker.mixin;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import net.millida.mod.cosmetics.CosmeticAssets;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = CosmeticAssets.class, remap = false)
public class CosmeticAssetsMixin {

    @Shadow @Final private Map<String, String> pendingJson;

    @Inject(method = "download", at = @At("HEAD"), cancellable = true, remap = false)
    private void tryLocalCacheFirst(String modelId, CallbackInfo ci) {
        System.out.println("[MillidaUnlocker] Requesting model: " + modelId);
        // Проверяем кэш официального лаунчера Millida в AppData\Roaming\net.millida.launcher\millida-mod-cache
        String appData = System.getenv("APPDATA");
        if (appData != null) {
            Path cacheDir = Paths.get(appData, "net.millida.launcher", "millida-mod-cache");
            Path[] candidates = new Path[] {
                cacheDir.resolve("models").resolve(modelId + ".json"),
                cacheDir.resolve("models").resolve(modelId),
                cacheDir.resolve("cosmetics").resolve("models").resolve(modelId + ".json"),
                cacheDir.resolve(modelId + ".json")
            };
            for (Path p : candidates) {
                if (Files.exists(p)) {
                    try {
                        String json = Files.readString(p, StandardCharsets.UTF_8);
                        if (!json.isEmpty()) {
                            System.out.println("[MillidaUnlocker] Loaded model from launcher cache: " + p);
                            this.pendingJson.put(modelId, json);
                            ci.cancel();
                            return;
                        }
                    } catch (Exception ignored) {}
                }
            }
        }
    }

    @Inject(method = "fail", at = @At("HEAD"), remap = false)
    private void logFail(String modelId, CallbackInfo ci) {
        System.out.println("[MillidaUnlocker] FAILED to download/parse model: " + modelId);
    }
}
