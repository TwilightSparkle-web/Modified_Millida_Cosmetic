package com.example.millidaunlocker.mixin;

import com.example.millidaunlocker.UnlockerConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.millida.core.MillidaCore;
import net.millida.core.cosmetics.CosmeticItem;
import net.millida.core.cosmetics.CosmeticSet;
import net.millida.core.cosmetics.CosmeticSlot;
import net.millida.core.cosmetics.EquippedCosmetic;
import net.millida.core.cosmetics.Wardrobe;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = Wardrobe.class, remap = false)
public abstract class WardrobeMixin {

    @Shadow @Final private MillidaCore core;
    @Shadow @Final private Map<CosmeticSlot, EquippedCosmetic> worn;
    @Shadow private UUID owner;
    @Shadow private boolean loaded;
    @Shadow private long editedAt;

    @Shadow protected abstract void notifyListeners();

    @Unique private boolean restoredFromDisk = false;

    @Unique
    private void pushToCosmeticService() {
        if (this.owner != null) {
            this.core.cosmetics().hold(this.owner, Long.MAX_VALUE / 2);
            this.core.cosmetics().accept(this.owner, new CosmeticSet(new ArrayList<>(this.worn.values())));
        }
    }

    @Unique
    private void restoreSavedOutfit() {
        if (this.restoredFromDisk || this.owner == null) return;
        this.restoredFromDisk = true;
        List<EquippedCosmetic> saved = UnlockerConfig.loadWorn();
        if (!saved.isEmpty()) {
            this.worn.clear();
            for (EquippedCosmetic item : saved) {
                this.worn.put(item.slot(), item);
            }
        }
        this.pushToCosmeticService();
    }

    @Inject(method = "owner", at = @At("HEAD"), cancellable = true, remap = false)
    private void ensureOwner(CallbackInfoReturnable<UUID> cir) {
        if (this.owner == null) {
            this.owner = UnlockerConfig.resolveUuid(null);
            this.restoreSavedOutfit();
        }
        cir.setReturnValue(this.owner);
    }

    @Inject(method = "bind", at = @At("HEAD"), cancellable = true, remap = false)
    private void customBind(UUID player, CallbackInfo ci) {
        UUID target = player != null ? player : UnlockerConfig.resolveUuid(null);
        if (!target.equals(this.owner)) {
            this.owner = target;
            this.loaded = true;
            this.restoredFromDisk = false;
            this.restoreSavedOutfit();
            this.notifyListeners();
        }
        ci.cancel();
    }


    @Inject(method = "locked", at = @At("HEAD"), cancellable = true, remap = false)
    private void unlockItem(CosmeticItem item, CallbackInfoReturnable<Boolean> cir) {
        if (item != null) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "lockedVariant", at = @At("HEAD"), cancellable = true, remap = false)
    private void unlockVariant(CosmeticItem item, String variant, CallbackInfoReturnable<Boolean> cir) {
        if (item != null) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "sync", at = @At("HEAD"), cancellable = true, remap = false)
    private void preventServerOverwrite(CallbackInfoReturnable<Boolean> cir) {
        if (this.owner == null) {
            this.owner = UnlockerConfig.resolveUuid(null);
        }
        this.restoreSavedOutfit();
        this.loaded = true;
        this.notifyListeners();
        cir.setReturnValue(true);
    }

    @Inject(method = "apply", at = @At("TAIL"), remap = false)
    private void keepLocalCosmetics(CallbackInfo ci) {
        this.editedAt = Long.MAX_VALUE / 2;
        this.pushToCosmeticService();
        UnlockerConfig.saveWorn(this.worn.values());
    }
}
