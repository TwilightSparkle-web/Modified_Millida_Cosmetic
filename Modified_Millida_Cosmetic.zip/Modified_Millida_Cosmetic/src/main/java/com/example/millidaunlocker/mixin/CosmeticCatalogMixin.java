package com.example.millidaunlocker.mixin;

import net.millida.core.cosmetics.CosmeticCatalog;
import net.millida.core.cosmetics.CosmeticItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = CosmeticCatalog.class, remap = false)
public class CosmeticCatalogMixin {

    @Inject(method = "available", at = @At("HEAD"), cancellable = true, remap = false)
    private void forceAvailable(CosmeticItem item, CallbackInfoReturnable<Boolean> cir) {
        if (item != null) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "availableVariant", at = @At("HEAD"), cancellable = true, remap = false)
    private void forceAvailableVariant(CosmeticItem item, String variant, CallbackInfoReturnable<Boolean> cir) {
        if (item != null) {
            cir.setReturnValue(true);
        }
    }
}
