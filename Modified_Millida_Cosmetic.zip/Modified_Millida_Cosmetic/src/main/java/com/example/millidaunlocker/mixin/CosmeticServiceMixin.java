package com.example.millidaunlocker.mixin;

import java.util.List;
import java.util.UUID;
import net.millida.core.cosmetics.CosmeticService;
import net.millida.core.cosmetics.CosmeticSet;
import net.millida.core.cosmetics.EquippedCosmetic;
import net.millida.mod.Millida;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = CosmeticService.class, remap = false)
public class CosmeticServiceMixin {

    @Inject(method = "peek", at = @At("HEAD"), cancellable = true, remap = false)
    private void returnLocalWorn(UUID player, CallbackInfoReturnable<CosmeticSet> cir) {
        if (player != null && Millida.started() && Millida.wardrobe() != null) {
            UUID owner = Millida.wardrobe().owner();
            if (owner == null || player.equals(owner)) {
                List<EquippedCosmetic> items = Millida.wardrobe().wornItems();
                if (!items.isEmpty()) {
                    cir.setReturnValue(new CosmeticSet(items));
                }
            }
        }
    }
}
