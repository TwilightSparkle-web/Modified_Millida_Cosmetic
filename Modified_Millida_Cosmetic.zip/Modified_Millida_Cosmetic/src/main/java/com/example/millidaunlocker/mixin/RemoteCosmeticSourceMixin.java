package com.example.millidaunlocker.mixin;

import net.millida.core.cosmetics.RemoteCosmeticSource;
import net.millida.core.http.HttpTransport;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = RemoteCosmeticSource.class, remap = false)
public class RemoteCosmeticSourceMixin {

    @Shadow @Final private HttpTransport transport;
    @Shadow @Final private String apiRoot;

    @Inject(method = "assetJson", at = @At("HEAD"), cancellable = true, remap = false)
    private void fetchModelUnsigned(String modelId, CallbackInfoReturnable<String> cir) {
        if (modelId != null && modelId.matches("[A-Za-z0-9_.:-]{1,64}")) {
            // Пробуем скачать модель обычным GET-запросом без заголовка Authorization
            String body = this.transport.getText(this.apiRoot + "/cosmetics/models/" + modelId);
            if (body != null && !body.isEmpty()) {
                cir.setReturnValue(body);
            }
        }
    }
}
